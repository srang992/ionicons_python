🍃**Releases**
----------------
###### **1.0.3**
- fixed path error while using colored icons.
###### **1.0.2**
- This library is now Stable. You can also see some new colored icons which are taken from icons8, flaticons, etc. The icons are listed below.

   -  `chatgpt_icon`
   -  `gmail_icon`
   -  `google_color_icon`
   -  `google_docs_icon`
   -  `google_sheets_icon`
   -  `google_drive_icon`
   -  `google_slides_icon`
   -  `streamlit_icon`
   -  `python_color_icon`
###### **0.1.4**
- bugs fixed and done improvements.
###### **0.1.3**
- previously the icons are only working with the desktop app of the **Flet**, not in the website. Now this bug is fixed. 
###### **0.1.2**
- First release in PyPI in Pre-Alpha Stage.